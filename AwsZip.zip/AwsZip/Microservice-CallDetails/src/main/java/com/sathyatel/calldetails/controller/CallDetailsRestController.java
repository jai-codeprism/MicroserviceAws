package com.sathyatel.calldetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.calldetails.dto.CallDetailsDto;
import com.sathyatel.calldetails.service.CallDetailsSercice;

@RestController
//@RequestMapping("/")
public class CallDetailsRestController {
	@Autowired
	private CallDetailsSercice service;
	 

	@GetMapping(value="/{phonenumber}",produces="application/json")
	public List<CallDetailsDto> getCallDetailsByPhoneNumber(@PathVariable("phonenumber") Long calledBy) {
		return service.getCallDetailsByPhoneNumber(calledBy);
	}

	
}
