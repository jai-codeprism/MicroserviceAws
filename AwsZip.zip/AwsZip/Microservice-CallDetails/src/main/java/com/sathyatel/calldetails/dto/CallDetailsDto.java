package com.sathyatel.calldetails.dto;

import java.util.Date;

import lombok.Data;
@Data
public class CallDetailsDto {
	private Long callId;
    
    private Long calledBy;
    
    private Long calledTo;
   
    private Date calledOn;
   
    private Integer duration;
}
