package com.sathyatel.calldetails.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.calldetails.dto.CallDetailsDto;
import com.sathyatel.calldetails.entity.CallDetails;
import com.sathyatel.calldetails.repository.CallDetailsRepository;
import com.sathyatel.calldetails.service.CallDetailsSercice;
@Service
public class CallDetailsServiceImpl implements CallDetailsSercice{
    @Autowired
	private CallDetailsRepository repo;
	/*
	 * @Override public List<CallDetails> findByCalledBy(Long calledBy) { return
	 * repo.findByCalledBy(calledBy); }
	 */

	@Override
	public List<CallDetailsDto> getCallDetailsByPhoneNumber(Long calledBy) {

		List<CallDetails> callDetailsList=repo.findByCalledBy(calledBy);
		//copy call details to call Details dto 
		List<CallDetailsDto> callDetailsDtoList=new ArrayList<>();//empty callDetailsDto list
		
				for(CallDetails callDetails:callDetailsList)//read one by one from call details list and copy from call details to dto and last add in callDetailsDtoList 
				{
					CallDetailsDto dto= new CallDetailsDto();
					BeanUtils.copyProperties(callDetails,dto); 
                    callDetailsDtoList.add(dto)	;				
				}
		return callDetailsDtoList;
	}

    
}
