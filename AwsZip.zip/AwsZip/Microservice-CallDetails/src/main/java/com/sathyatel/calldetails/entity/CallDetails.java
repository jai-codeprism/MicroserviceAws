package com.sathyatel.calldetails.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
public class CallDetails {

	@Id
	@GeneratedValue
	private Long callId;
    @NonNull
    private Long calledBy;
    @NonNull
    private Long calledTo;
    @NonNull
    @Temporal(TemporalType.DATE)
    private Date calledOn;
    @NonNull
    private Integer duration;
}
