package com.sathyatel.calldetails.service;

import java.util.List;

import com.sathyatel.calldetails.dto.CallDetailsDto;

public interface CallDetailsSercice {

	//List<CallDetails>findByCalledBy(Long calledBy);
	List<CallDetailsDto>getCallDetailsByPhoneNumber(Long calledBy);
	
}
